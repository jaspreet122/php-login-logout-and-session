# Simple-Login-logout-system-using-PHP
Simple login and logout system using PHP and Mysql
#developed by Prem Lamsal --> premlamsal2@gmail.com
feel free to use codes.
Thank you!
Import database from folder "database"
